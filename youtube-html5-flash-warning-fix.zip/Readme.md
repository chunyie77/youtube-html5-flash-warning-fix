
# YouTube HTML5 Flash Warning Fix <sup>0.0.1</sup>

Automatically replaces the Adobe Flash warning message with an embedded HTML5 player (if you have Flash disabled). Silly bug YouTube hasn't fixed yet, so I did.

## Contributors

* Nick Baugh <niftylettuce@gmail.com>

## License

MIT Licensed
